<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/djs' => [[['_route' => 'djs_index', '_controller' => 'App\\Controller\\DjsController::index'], null, ['GET' => 0], null, true, false, null]],
        '/djs/new' => [[['_route' => 'djs_new', '_controller' => 'App\\Controller\\DjsController::new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/hard/techyes' => [[['_route' => 'hard_techyes_index', '_controller' => 'App\\Controller\\HardTechyesController::index'], null, ['GET' => 0], null, true, false, null]],
        '/hard/techyes/new' => [[['_route' => 'hard_techyes_new', '_controller' => 'App\\Controller\\HardTechyesController::new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/techyes' => [[['_route' => 'techyes_index', '_controller' => 'App\\Controller\\TechyesController::index'], null, ['GET' => 0], null, true, false, null]],
        '/techyes/new' => [[['_route' => 'techyes_new', '_controller' => 'App\\Controller\\TechyesController::new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/_error/(\\d+)(?:\\.([^/]++))?(*:35)'
                .'|/djs/([^/]++)(?'
                    .'|(*:58)'
                    .'|/edit(*:70)'
                    .'|(*:77)'
                .')'
                .'|/hard/techyes/([^/]++)(?'
                    .'|(*:110)'
                    .'|/edit(*:123)'
                    .'|(*:131)'
                .')'
                .'|/techyes/([^/]++)(?'
                    .'|(*:160)'
                    .'|/edit(*:173)'
                    .'|(*:181)'
                .')'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        35 => [[['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null]],
        58 => [[['_route' => 'djs_show', '_controller' => 'App\\Controller\\DjsController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        70 => [[['_route' => 'djs_edit', '_controller' => 'App\\Controller\\DjsController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        77 => [[['_route' => 'djs_delete', '_controller' => 'App\\Controller\\DjsController::delete'], ['id'], ['DELETE' => 0], null, false, true, null]],
        110 => [[['_route' => 'hard_techyes_show', '_controller' => 'App\\Controller\\HardTechyesController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        123 => [[['_route' => 'hard_techyes_edit', '_controller' => 'App\\Controller\\HardTechyesController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        131 => [[['_route' => 'hard_techyes_delete', '_controller' => 'App\\Controller\\HardTechyesController::delete'], ['id'], ['DELETE' => 0], null, false, true, null]],
        160 => [[['_route' => 'techyes_show', '_controller' => 'App\\Controller\\TechyesController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        173 => [[['_route' => 'techyes_edit', '_controller' => 'App\\Controller\\TechyesController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        181 => [
            [['_route' => 'techyes_delete', '_controller' => 'App\\Controller\\TechyesController::delete'], ['id'], ['DELETE' => 0], null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
