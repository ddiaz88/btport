<?php

namespace ContainerKY0DLaj;
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'persistence'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'Persistence'.\DIRECTORY_SEPARATOR.'ObjectManager.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManagerInterface.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManager.php';

class EntityManager_9a5be93 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{
    /**
     * @var \Doctrine\ORM\EntityManager|null wrapped object, if the proxy is initialized
     */
    private $valueHolderba365 = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializerf1024 = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicProperties45241 = [
        
    ];

    public function getConnection()
    {
        $this->initializerf1024 && ($this->initializerf1024->__invoke($valueHolderba365, $this, 'getConnection', array(), $this->initializerf1024) || 1) && $this->valueHolderba365 = $valueHolderba365;

        return $this->valueHolderba365->getConnection();
    }

    public function getMetadataFactory()
    {
        $this->initializerf1024 && ($this->initializerf1024->__invoke($valueHolderba365, $this, 'getMetadataFactory', array(), $this->initializerf1024) || 1) && $this->valueHolderba365 = $valueHolderba365;

        return $this->valueHolderba365->getMetadataFactory();
    }

    public function getExpressionBuilder()
    {
        $this->initializerf1024 && ($this->initializerf1024->__invoke($valueHolderba365, $this, 'getExpressionBuilder', array(), $this->initializerf1024) || 1) && $this->valueHolderba365 = $valueHolderba365;

        return $this->valueHolderba365->getExpressionBuilder();
    }

    public function beginTransaction()
    {
        $this->initializerf1024 && ($this->initializerf1024->__invoke($valueHolderba365, $this, 'beginTransaction', array(), $this->initializerf1024) || 1) && $this->valueHolderba365 = $valueHolderba365;

        return $this->valueHolderba365->beginTransaction();
    }

    public function getCache()
    {
        $this->initializerf1024 && ($this->initializerf1024->__invoke($valueHolderba365, $this, 'getCache', array(), $this->initializerf1024) || 1) && $this->valueHolderba365 = $valueHolderba365;

        return $this->valueHolderba365->getCache();
    }

    public function transactional($func)
    {
        $this->initializerf1024 && ($this->initializerf1024->__invoke($valueHolderba365, $this, 'transactional', array('func' => $func), $this->initializerf1024) || 1) && $this->valueHolderba365 = $valueHolderba365;

        return $this->valueHolderba365->transactional($func);
    }

    public function commit()
    {
        $this->initializerf1024 && ($this->initializerf1024->__invoke($valueHolderba365, $this, 'commit', array(), $this->initializerf1024) || 1) && $this->valueHolderba365 = $valueHolderba365;

        return $this->valueHolderba365->commit();
    }

    public function rollback()
    {
        $this->initializerf1024 && ($this->initializerf1024->__invoke($valueHolderba365, $this, 'rollback', array(), $this->initializerf1024) || 1) && $this->valueHolderba365 = $valueHolderba365;

        return $this->valueHolderba365->rollback();
    }

    public function getClassMetadata($className)
    {
        $this->initializerf1024 && ($this->initializerf1024->__invoke($valueHolderba365, $this, 'getClassMetadata', array('className' => $className), $this->initializerf1024) || 1) && $this->valueHolderba365 = $valueHolderba365;

        return $this->valueHolderba365->getClassMetadata($className);
    }

    public function createQuery($dql = '')
    {
        $this->initializerf1024 && ($this->initializerf1024->__invoke($valueHolderba365, $this, 'createQuery', array('dql' => $dql), $this->initializerf1024) || 1) && $this->valueHolderba365 = $valueHolderba365;

        return $this->valueHolderba365->createQuery($dql);
    }

    public function createNamedQuery($name)
    {
        $this->initializerf1024 && ($this->initializerf1024->__invoke($valueHolderba365, $this, 'createNamedQuery', array('name' => $name), $this->initializerf1024) || 1) && $this->valueHolderba365 = $valueHolderba365;

        return $this->valueHolderba365->createNamedQuery($name);
    }

    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializerf1024 && ($this->initializerf1024->__invoke($valueHolderba365, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializerf1024) || 1) && $this->valueHolderba365 = $valueHolderba365;

        return $this->valueHolderba365->createNativeQuery($sql, $rsm);
    }

    public function createNamedNativeQuery($name)
    {
        $this->initializerf1024 && ($this->initializerf1024->__invoke($valueHolderba365, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializerf1024) || 1) && $this->valueHolderba365 = $valueHolderba365;

        return $this->valueHolderba365->createNamedNativeQuery($name);
    }

    public function createQueryBuilder()
    {
        $this->initializerf1024 && ($this->initializerf1024->__invoke($valueHolderba365, $this, 'createQueryBuilder', array(), $this->initializerf1024) || 1) && $this->valueHolderba365 = $valueHolderba365;

        return $this->valueHolderba365->createQueryBuilder();
    }

    public function flush($entity = null)
    {
        $this->initializerf1024 && ($this->initializerf1024->__invoke($valueHolderba365, $this, 'flush', array('entity' => $entity), $this->initializerf1024) || 1) && $this->valueHolderba365 = $valueHolderba365;

        return $this->valueHolderba365->flush($entity);
    }

    public function find($className, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializerf1024 && ($this->initializerf1024->__invoke($valueHolderba365, $this, 'find', array('className' => $className, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializerf1024) || 1) && $this->valueHolderba365 = $valueHolderba365;

        return $this->valueHolderba365->find($className, $id, $lockMode, $lockVersion);
    }

    public function getReference($entityName, $id)
    {
        $this->initializerf1024 && ($this->initializerf1024->__invoke($valueHolderba365, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializerf1024) || 1) && $this->valueHolderba365 = $valueHolderba365;

        return $this->valueHolderba365->getReference($entityName, $id);
    }

    public function getPartialReference($entityName, $identifier)
    {
        $this->initializerf1024 && ($this->initializerf1024->__invoke($valueHolderba365, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializerf1024) || 1) && $this->valueHolderba365 = $valueHolderba365;

        return $this->valueHolderba365->getPartialReference($entityName, $identifier);
    }

    public function clear($entityName = null)
    {
        $this->initializerf1024 && ($this->initializerf1024->__invoke($valueHolderba365, $this, 'clear', array('entityName' => $entityName), $this->initializerf1024) || 1) && $this->valueHolderba365 = $valueHolderba365;

        return $this->valueHolderba365->clear($entityName);
    }

    public function close()
    {
        $this->initializerf1024 && ($this->initializerf1024->__invoke($valueHolderba365, $this, 'close', array(), $this->initializerf1024) || 1) && $this->valueHolderba365 = $valueHolderba365;

        return $this->valueHolderba365->close();
    }

    public function persist($entity)
    {
        $this->initializerf1024 && ($this->initializerf1024->__invoke($valueHolderba365, $this, 'persist', array('entity' => $entity), $this->initializerf1024) || 1) && $this->valueHolderba365 = $valueHolderba365;

        return $this->valueHolderba365->persist($entity);
    }

    public function remove($entity)
    {
        $this->initializerf1024 && ($this->initializerf1024->__invoke($valueHolderba365, $this, 'remove', array('entity' => $entity), $this->initializerf1024) || 1) && $this->valueHolderba365 = $valueHolderba365;

        return $this->valueHolderba365->remove($entity);
    }

    public function refresh($entity)
    {
        $this->initializerf1024 && ($this->initializerf1024->__invoke($valueHolderba365, $this, 'refresh', array('entity' => $entity), $this->initializerf1024) || 1) && $this->valueHolderba365 = $valueHolderba365;

        return $this->valueHolderba365->refresh($entity);
    }

    public function detach($entity)
    {
        $this->initializerf1024 && ($this->initializerf1024->__invoke($valueHolderba365, $this, 'detach', array('entity' => $entity), $this->initializerf1024) || 1) && $this->valueHolderba365 = $valueHolderba365;

        return $this->valueHolderba365->detach($entity);
    }

    public function merge($entity)
    {
        $this->initializerf1024 && ($this->initializerf1024->__invoke($valueHolderba365, $this, 'merge', array('entity' => $entity), $this->initializerf1024) || 1) && $this->valueHolderba365 = $valueHolderba365;

        return $this->valueHolderba365->merge($entity);
    }

    public function copy($entity, $deep = false)
    {
        $this->initializerf1024 && ($this->initializerf1024->__invoke($valueHolderba365, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializerf1024) || 1) && $this->valueHolderba365 = $valueHolderba365;

        return $this->valueHolderba365->copy($entity, $deep);
    }

    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializerf1024 && ($this->initializerf1024->__invoke($valueHolderba365, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializerf1024) || 1) && $this->valueHolderba365 = $valueHolderba365;

        return $this->valueHolderba365->lock($entity, $lockMode, $lockVersion);
    }

    public function getRepository($entityName)
    {
        $this->initializerf1024 && ($this->initializerf1024->__invoke($valueHolderba365, $this, 'getRepository', array('entityName' => $entityName), $this->initializerf1024) || 1) && $this->valueHolderba365 = $valueHolderba365;

        return $this->valueHolderba365->getRepository($entityName);
    }

    public function contains($entity)
    {
        $this->initializerf1024 && ($this->initializerf1024->__invoke($valueHolderba365, $this, 'contains', array('entity' => $entity), $this->initializerf1024) || 1) && $this->valueHolderba365 = $valueHolderba365;

        return $this->valueHolderba365->contains($entity);
    }

    public function getEventManager()
    {
        $this->initializerf1024 && ($this->initializerf1024->__invoke($valueHolderba365, $this, 'getEventManager', array(), $this->initializerf1024) || 1) && $this->valueHolderba365 = $valueHolderba365;

        return $this->valueHolderba365->getEventManager();
    }

    public function getConfiguration()
    {
        $this->initializerf1024 && ($this->initializerf1024->__invoke($valueHolderba365, $this, 'getConfiguration', array(), $this->initializerf1024) || 1) && $this->valueHolderba365 = $valueHolderba365;

        return $this->valueHolderba365->getConfiguration();
    }

    public function isOpen()
    {
        $this->initializerf1024 && ($this->initializerf1024->__invoke($valueHolderba365, $this, 'isOpen', array(), $this->initializerf1024) || 1) && $this->valueHolderba365 = $valueHolderba365;

        return $this->valueHolderba365->isOpen();
    }

    public function getUnitOfWork()
    {
        $this->initializerf1024 && ($this->initializerf1024->__invoke($valueHolderba365, $this, 'getUnitOfWork', array(), $this->initializerf1024) || 1) && $this->valueHolderba365 = $valueHolderba365;

        return $this->valueHolderba365->getUnitOfWork();
    }

    public function getHydrator($hydrationMode)
    {
        $this->initializerf1024 && ($this->initializerf1024->__invoke($valueHolderba365, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializerf1024) || 1) && $this->valueHolderba365 = $valueHolderba365;

        return $this->valueHolderba365->getHydrator($hydrationMode);
    }

    public function newHydrator($hydrationMode)
    {
        $this->initializerf1024 && ($this->initializerf1024->__invoke($valueHolderba365, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializerf1024) || 1) && $this->valueHolderba365 = $valueHolderba365;

        return $this->valueHolderba365->newHydrator($hydrationMode);
    }

    public function getProxyFactory()
    {
        $this->initializerf1024 && ($this->initializerf1024->__invoke($valueHolderba365, $this, 'getProxyFactory', array(), $this->initializerf1024) || 1) && $this->valueHolderba365 = $valueHolderba365;

        return $this->valueHolderba365->getProxyFactory();
    }

    public function initializeObject($obj)
    {
        $this->initializerf1024 && ($this->initializerf1024->__invoke($valueHolderba365, $this, 'initializeObject', array('obj' => $obj), $this->initializerf1024) || 1) && $this->valueHolderba365 = $valueHolderba365;

        return $this->valueHolderba365->initializeObject($obj);
    }

    public function getFilters()
    {
        $this->initializerf1024 && ($this->initializerf1024->__invoke($valueHolderba365, $this, 'getFilters', array(), $this->initializerf1024) || 1) && $this->valueHolderba365 = $valueHolderba365;

        return $this->valueHolderba365->getFilters();
    }

    public function isFiltersStateClean()
    {
        $this->initializerf1024 && ($this->initializerf1024->__invoke($valueHolderba365, $this, 'isFiltersStateClean', array(), $this->initializerf1024) || 1) && $this->valueHolderba365 = $valueHolderba365;

        return $this->valueHolderba365->isFiltersStateClean();
    }

    public function hasFilters()
    {
        $this->initializerf1024 && ($this->initializerf1024->__invoke($valueHolderba365, $this, 'hasFilters', array(), $this->initializerf1024) || 1) && $this->valueHolderba365 = $valueHolderba365;

        return $this->valueHolderba365->hasFilters();
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();

        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $instance, 'Doctrine\\ORM\\EntityManager')->__invoke($instance);

        $instance->initializerf1024 = $initializer;

        return $instance;
    }

    protected function __construct(\Doctrine\DBAL\Connection $conn, \Doctrine\ORM\Configuration $config, \Doctrine\Common\EventManager $eventManager)
    {
        static $reflection;

        if (! $this->valueHolderba365) {
            $reflection = $reflection ?? new \ReflectionClass('Doctrine\\ORM\\EntityManager');
            $this->valueHolderba365 = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);

        }

        $this->valueHolderba365->__construct($conn, $config, $eventManager);
    }

    public function & __get($name)
    {
        $this->initializerf1024 && ($this->initializerf1024->__invoke($valueHolderba365, $this, '__get', ['name' => $name], $this->initializerf1024) || 1) && $this->valueHolderba365 = $valueHolderba365;

        if (isset(self::$publicProperties45241[$name])) {
            return $this->valueHolderba365->$name;
        }

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolderba365;

            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }

        $targetObject = $this->valueHolderba365;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializerf1024 && ($this->initializerf1024->__invoke($valueHolderba365, $this, '__set', array('name' => $name, 'value' => $value), $this->initializerf1024) || 1) && $this->valueHolderba365 = $valueHolderba365;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolderba365;

            $targetObject->$name = $value;

            return $targetObject->$name;
        }

        $targetObject = $this->valueHolderba365;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;

            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializerf1024 && ($this->initializerf1024->__invoke($valueHolderba365, $this, '__isset', array('name' => $name), $this->initializerf1024) || 1) && $this->valueHolderba365 = $valueHolderba365;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolderba365;

            return isset($targetObject->$name);
        }

        $targetObject = $this->valueHolderba365;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializerf1024 && ($this->initializerf1024->__invoke($valueHolderba365, $this, '__unset', array('name' => $name), $this->initializerf1024) || 1) && $this->valueHolderba365 = $valueHolderba365;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolderba365;

            unset($targetObject->$name);

            return;
        }

        $targetObject = $this->valueHolderba365;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);

            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }

    public function __clone()
    {
        $this->initializerf1024 && ($this->initializerf1024->__invoke($valueHolderba365, $this, '__clone', array(), $this->initializerf1024) || 1) && $this->valueHolderba365 = $valueHolderba365;

        $this->valueHolderba365 = clone $this->valueHolderba365;
    }

    public function __sleep()
    {
        $this->initializerf1024 && ($this->initializerf1024->__invoke($valueHolderba365, $this, '__sleep', array(), $this->initializerf1024) || 1) && $this->valueHolderba365 = $valueHolderba365;

        return array('valueHolderba365');
    }

    public function __wakeup()
    {
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializerf1024 = $initializer;
    }

    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializerf1024;
    }

    public function initializeProxy() : bool
    {
        return $this->initializerf1024 && ($this->initializerf1024->__invoke($valueHolderba365, $this, 'initializeProxy', array(), $this->initializerf1024) || 1) && $this->valueHolderba365 = $valueHolderba365;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolderba365;
    }

    public function getWrappedValueHolderValue()
    {
        return $this->valueHolderba365;
    }
}

if (!\class_exists('EntityManager_9a5be93', false)) {
    \class_alias(__NAMESPACE__.'\\EntityManager_9a5be93', 'EntityManager_9a5be93', false);
}
